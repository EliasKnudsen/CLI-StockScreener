What you can do:

1. 
    You can perform regular scans, this exports it to Export.csv in your directory. This scan is the same as finviz.com screener, but it exports to csv.
2. 
    You can save your own filters, and perform scans with them. 
    The result from the scan is saved by date, which you can perform same filter scan on, the next days, and track how the perform.